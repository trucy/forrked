<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
	<div id="search">
	<div id="searchbox">
	<input type="text" value="<?php if (isset($_GET['s'])) echo wp_specialchars($_GET['s'], 1); else echo 'search forrked.com' ?>" name="s" id="s"  onblur="if (this.value == '') {this.value = 'search forrked.com';}" onfocus="if (this.value == 'search forrked.com') {this.value = '';}" onclick="if (this.value == 'search forrked.com') {this.value = '';}" />
	</div><!-- #searchbox -->
	<div id="searchbutton">
	<input type="image" id="searchsubmit" src="/wp-content/themes/forrked/images/search.png" class="button" />
	</div><!-- #searchbutton -->
  </div><!-- #search -->
</form>