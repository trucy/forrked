<?php
/*
Template Name: Search Page
*/

get_header(); ?>

		<div id="container">
			
			<div id="content" role="main">

					<div class="entry-content">
						<?php include (TEMPLATEPATH . '/searchform.php'); ?>
					</div><!-- .entry-content -->
					

<?php endwhile; ?>

			</div><!-- #content -->
			
		</div><!-- #container -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>